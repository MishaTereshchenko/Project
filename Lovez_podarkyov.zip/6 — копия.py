import os
import pygame
import random
import sys

pygame.init()
font = pygame.font.Font(None, 32)
size = width, height = 824, 400
screen = pygame.display.set_mode(size)
screen_rect = (0, 0, 824, 400)


def terminate():
    pygame.quit()
    sys.exit()


def load_image(name, color_key=None):
    fullname = os.path.join(name)
    image = pygame.image.load(fullname).convert()

    if color_key is not None:
        if color_key == -1:
            color_key = image.get_at((0, 0))
        image.set_colorkey(color_key)
    else:
        image = image.convert_alpha()
    return image


def win_screen():
    intro_text = [
        "GAME OVER",
        "Что мы имеем в итоге:",
        "Вы собрали аж " + str(k) + " подарков",
        "Количество количество оставшихся жизней всего " + str(l),
        "На этом всё!",
        "Далее необходимо закрыть окно,",
        "нажав на крестик или пробел"
    ]

    fon = pygame.transform.scale(load_image('start_image.png'), (width, height))
    screen.blit(fon, (0, 0))
    font = pygame.font.Font(None, 30)
    text_coord = 50
    for line in intro_text:
        string_rendered = font.render(line, 1, pygame.Color('black'))
        intro_rect = string_rendered.get_rect()
        text_coord += 15
        intro_rect.top = text_coord
        intro_rect.x = 15
        text_coord += intro_rect.height
        screen.blit(string_rendered, intro_rect)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    return  # начинаем игру
        pygame.display.flip()
        clock.tick(fps)


def start_screen():
    intro_text = [
        "Правила игры:",
        "цель этой игры -это  собирать подарки.",
        "Подарки будут падать сверху."
        "Игрок должен собрать их,",
        "управляя ноогодним мешком,",
        "При этом если вы потеряете 5 жизней - погибните, ",
        "За каждые 2 пропущенных подарка снимается 1 жизнь."
        "",
        "Для управления направлением движения",
        "нужно нажимать на соответствующие кнопки-стрелки",
        "",
        "Для того чтобы начать игру, нажать любую клавишу"
    ]
    fon = pygame.transform.scale(load_image('start_image.png'), (width, height))
    screen.blit(fon, (0, 0))
    font = pygame.font.Font(None, 30)
    text_coord = 50
    for line in intro_text:
        string_rendered = font.render(line, 1, pygame.Color('black'))
        intro_rect = string_rendered.get_rect()
        text_coord += 10
        intro_rect.top = text_coord
        intro_rect.x = 10
        text_coord += intro_rect.height
        screen.blit(string_rendered, intro_rect)
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()  # выход
            elif event.type == pygame.KEYDOWN:
                return  # начало игры
        pygame.display.flip()
        clock.tick(fps)


def end_screen(k, all_gifts, l):
    fps = 60
    intro_text = [
        "GAME OVER",
        "Что мы имеем в итоге:",
        "Вы собрали аж " + str(k) + " подарков из " + str(all_gifts),
        "Количество количество оставшихся жизней всего " + str(l),
        "На этом всё!",
        "Далее необходимо закрыть окно,",
        "нажав на крестик или пробел"
    ]

    fon = pygame.transform.scale(load_image('start_image.png'), (width, height))
    screen.blit(fon, (0, 0))
    font = pygame.font.Font(None, 30)
    text_coord = 50
    for line in intro_text:
        string_rendered = font.render(line, 1, pygame.Color('black'))
        intro_rect = string_rendered.get_rect()
        text_coord += 15
        intro_rect.top = text_coord
        intro_rect.x = 15
        text_coord += intro_rect.height
        screen.blit(string_rendered, intro_rect)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    return  # начинаем игру
        pygame.display.flip()
        clock.tick(fps)


class Gift(pygame.sprite.Sprite):
    image = load_image("1.png", -1)
    k = 0

    def __init__(self):
        # НЕОБХОДИМО вызвать конструктор родительского класса Sprite
        super().__init__(gift_group, all_sprites)
        self.image = Gift.image
        self.rect = self.image.get_rect()
        self.rect.x = random.randint(70, width - 70)
        self.rect.y = 0
        self.rect[3] = 30
        self.rect[2] = 30

    def update(self):
        self.rect.y += 1
        if not self.rect.colliderect(screen_rect):
            self.kill()
            Meshok.all_gifts += 1
        if pygame.sprite.spritecollide(self, player_sprites, False):
            self.kill()
            Gift.k += 1
            Meshok.all_gifts += 1

    def get_cor(self):
        return self.rect.x, self.rect.y


class Meshok(pygame.sprite.Sprite):
    image = load_image("2.png", -1)
    level = 1
    all_gifts = 0
    do = True
    l = 5

    def __init__(self):
        # НЕОБХОДИМО вызвать конструктор родительского класса Sprite
        super().__init__(player_sprites, all_sprites)
        self.image = Meshok.image
        self.k = 0
        self.rect = self.image.get_rect()
        self.rect.x = 250
        self.rect.y = 230

    def update(self, x):
        self.rect.x += x


def level_1():
    fps = 60
    intro_text = [
        "Pause",
        "Что мы имеем в итоге:",
        "Вы собрали " + str(Gift.k) + " подарков из " + str(Meshok.all_gifts),
        "Количество количество оставшихся жизней всего " + str(Meshok.l),
        "",
        "Для того чтобы продолжить игру, нажмите на пробел"
    ]

    fon = pygame.transform.scale(load_image('start_image.png'), (width, height))
    screen.blit(fon, (0, 0))
    font = pygame.font.Font(None, 30)
    text_coord = 50
    for line in intro_text:
        string_rendered = font.render(line, 1, pygame.Color('black'))
        intro_rect = string_rendered.get_rect()
        text_coord += 15
        intro_rect.top = text_coord
        intro_rect.x = 15
        text_coord += intro_rect.height
        screen.blit(string_rendered, intro_rect)

    run = True
    while run:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    run = False  # начинаем игру
        pygame.display.flip()
        clock.tick(fps)

    gift_group = pygame.sprite.Group()
    upav_gifts = 0
    all_gifts = 3
    fps = 20
    t = 0
    fon = load_image('fon.jpg')
    running = True
    while running and Meshok.do:
        step = 0
        if t % 50 == 0 and upav_gifts < all_gifts:
            gift_group.add(Gift())
            upav_gifts += 1
        font = pygame.font.Font(None, 32)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                Meshok.do = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    if player.rect.x - 1 >= 0:
                        step = -30
                if event.key == pygame.K_RIGHT:
                    if player.rect.x + 1 <= width:
                        step = 30
        screen.fill('black')
        screen.blit(fon, (0, 0))
        all_sprites.draw(screen)
        t += 1
        player_sprites.draw(screen)
        player_sprites.update(step)
        gift_group.update()
        k = Gift.k
        text = font.render(
            "Уровень " + str(Meshok.level) + " Подарков " + str(k) + " из " + str(Meshok.all_gifts),
            None, (100, 200, 0))
        screen.blit(text, (10, 10))
        clock.tick(fps)
        pygame.display.flip()
        if len(gift_group) == 0:
            running = False
            Meshok.level += 1


def level_2():
    fps = 60
    intro_text = [
        "Pause",
        "Что мы имеем в итоге:",
        "Вы собрали " + str(Gift.k) + " подарков из " + str(Meshok.all_gifts),
        "Количество количество оставшихся жизней всего " + str(Meshok.l),
        "",
        "Для того чтобы продолжить игру, нажмите на пробел"
    ]

    fon = pygame.transform.scale(load_image('start_image.png'), (width, height))
    screen.blit(fon, (0, 0))
    font = pygame.font.Font(None, 30)
    text_coord = 50
    for line in intro_text:
        string_rendered = font.render(line, 1, pygame.Color('black'))
        intro_rect = string_rendered.get_rect()
        text_coord += 15
        intro_rect.top = text_coord
        intro_rect.x = 15
        text_coord += intro_rect.height
        screen.blit(string_rendered, intro_rect)

    run = True
    while run:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    run = False  # начинаем игру
        pygame.display.flip()
        clock.tick(fps)

    gift_group = pygame.sprite.Group()
    upav_gifts = 0
    all_gifts = 5
    fps = 40
    fon = load_image('fon.jpg')
    t = 0
    running = True
    while running and Meshok.do:
        step = 0
        if t % 40 == 0 and upav_gifts < all_gifts:
            gift_group.add(Gift())
            upav_gifts += 1
        font = pygame.font.Font(None, 32)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                Meshok.do = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    if player.rect.x - 1 >= 0:
                        step = -40
                if event.key == pygame.K_RIGHT:
                    if player.rect.x + 1 <= width:
                        step = 40
        screen.fill('black')
        screen.blit(fon, (0, 0))
        all_sprites.draw(screen)
        t += 1
        player_sprites.draw(screen)
        player_sprites.update(step)
        gift_group.update()
        k = Gift.k
        text = font.render(
            "Уровень " + str(Meshok.level) + " Подарков " + str(k) + " из " + str(Meshok.all_gifts),
            None, (100, 200, 0))
        screen.blit(text, (10, 10))
        clock.tick(fps)
        pygame.display.flip()
        if len(gift_group) == 0:
            running = False
            Meshok.level += 1


def level_3():
    fps = 60
    intro_text = [
        "Pause",
        "Что мы имеем в итоге:",
        "Вы собрали " + str(Gift.k) + " подарков из " + str(Meshok.all_gifts),
        "Количество количество оставшихся жизней всего " + str(Meshok.l),
        "",
        "Для того чтобы продолжить игру, нажмите на пробел"
    ]

    fon = pygame.transform.scale(load_image('start_image.png'), (width, height))
    screen.blit(fon, (0, 0))
    font = pygame.font.Font(None, 30)
    text_coord = 50
    for line in intro_text:
        string_rendered = font.render(line, 1, pygame.Color('black'))
        intro_rect = string_rendered.get_rect()
        text_coord += 15
        intro_rect.top = text_coord
        intro_rect.x = 15
        text_coord += intro_rect.height
        screen.blit(string_rendered, intro_rect)

    run = True
    while run:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    run = False  # начинаем игру
        pygame.display.flip()
        clock.tick(fps)

    gift_group = pygame.sprite.Group()
    upav_gifts = 0
    all_gifts = 8
    fps = 60
    fon = load_image('fon.jpg')
    t = 0
    running = True
    while running and Meshok.do:
        step = 0
        if t % 40 == 0 and upav_gifts < all_gifts:
            gift_group.add(Gift())
            upav_gifts += 1
        font = pygame.font.Font(None, 32)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                Meshok.do = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    if player.rect.x - 1 >= 0:
                        step = -50
                if event.key == pygame.K_RIGHT:
                    if player.rect.x + 1 <= width:
                        step = 50
        screen.fill('black')
        screen.blit(fon, (0, 0))
        all_sprites.draw(screen)
        t += 1
        player_sprites.draw(screen)
        player_sprites.update(step)
        gift_group.update()
        k = Gift.k
        text = font.render(
            "Уровень " + str(Meshok.level) + " Подарков " + str(k) + " из " + str(Meshok.all_gifts),
            None, (100, 200, 0))
        screen.blit(text, (10, 10))
        clock.tick(fps)
        pygame.display.flip()
        if len(gift_group) == 0:
            running = False
            Meshok.level += 1


def level_4():
    fps = 60
    intro_text = [
        "Pause",
        "Что мы имеем в итоге:",
        "Вы собрали " + str(Gift.k) + " подарков из " + str(Meshok.all_gifts),
        "Количество количество оставшихся жизней всего " + str(Meshok.l),
        "",
        "Для того чтобы продолжить игру, нажмите на пробел"
    ]

    fon = pygame.transform.scale(load_image('start_image.png'), (width, height))
    screen.blit(fon, (0, 0))
    font = pygame.font.Font(None, 30)
    text_coord = 50
    for line in intro_text:
        string_rendered = font.render(line, 1, pygame.Color('black'))
        intro_rect = string_rendered.get_rect()
        text_coord += 15
        intro_rect.top = text_coord
        intro_rect.x = 15
        text_coord += intro_rect.height
        screen.blit(string_rendered, intro_rect)

    run = True
    while run:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    run = False  # начинаем игру
        pygame.display.flip()
        clock.tick(fps)

    gift_group = pygame.sprite.Group()
    upav_gifts = 0
    all_gifts = 10
    t = 0
    fps = 80
    fon = load_image('fon.jpg')
    running = True
    while running and Meshok.do:
        step = 0
        if t % 20 == 0 and upav_gifts < all_gifts:
            gift_group.add(Gift())
            upav_gifts += 1
        font = pygame.font.Font(None, 32)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                Meshok.do = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    if player.rect.x - 1 >= 0:
                        step = -70
                if event.key == pygame.K_RIGHT:
                    if player.rect.x + 1 <= width:
                        step = 70
        screen.fill('black')
        screen.blit(fon, (0, 0))
        all_sprites.draw(screen)
        t += 1
        player_sprites.draw(screen)
        player_sprites.update(step)
        gift_group.update()
        k = Gift.k
        text = font.render(
            "Уровень " + str(Meshok.level) + " Подарков " + str(k) + " из " + str(Meshok.all_gifts),
            None, (100, 200, 0))
        screen.blit(text, (10, 10))
        clock.tick(fps)
        pygame.display.flip()
        if len(gift_group) == 0:
            running = False
            Meshok.level += 1


def level_5():
    fps = 60
    intro_text = [
        "Pause",
        "Что мы имеем в итоге:",
        "Вы собрали " + str(Gift.k) + " подарков из " + str(Meshok.all_gifts),
        "Количество количество оставшихся жизней всего " + str(Meshok.l),
        "",
        "Для того чтобы продолжить игру, нажмите на пробел"
    ]

    fon = pygame.transform.scale(load_image('start_image.png'), (width, height))
    screen.blit(fon, (0, 0))
    font = pygame.font.Font(None, 30)
    text_coord = 50
    for line in intro_text:
        string_rendered = font.render(line, 1, pygame.Color('black'))
        intro_rect = string_rendered.get_rect()
        text_coord += 15
        intro_rect.top = text_coord
        intro_rect.x = 15
        text_coord += intro_rect.height
        screen.blit(string_rendered, intro_rect)

    run = True
    while run:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    run = False  # начинаем игру
        pygame.display.flip()
        clock.tick(fps)

    gift_group = pygame.sprite.Group()
    upav_gifts = 0
    all_gifts = 12
    t = 0
    fps = 90
    fon = load_image('fon.jpg')
    running = True
    while running and Meshok.do:
        step = 0
        if t % 40 == 0 and upav_gifts < all_gifts:
            gift_group.add(Gift())
            upav_gifts += 1
        font = pygame.font.Font(None, 32)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                Meshok.do = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    if player.rect.x - 1 >= 0:
                        step = -80
                if event.key == pygame.K_RIGHT:
                    if player.rect.x + 1 <= width:
                        step = 80
        screen.fill('black')
        screen.blit(fon, (0, 0))
        all_sprites.draw(screen)
        t += 1
        player_sprites.draw(screen)
        player_sprites.update(step)
        gift_group.update()
        k = Gift.k
        text = font.render(
            "Уровень " + str(Meshok.level) + " Подарков " + str(k) + " из " + str(Meshok.all_gifts),
            None, (100, 200, 0))
        screen.blit(text, (10, 10))
        clock.tick(fps)
        pygame.display.flip()
        if len(gift_group) == 0:
            running = False
            Meshok.level += 1


# группа, содержащая все спрайты
all_sprites = pygame.sprite.Group()
player_sprites = pygame.sprite.Group()
gift_group = pygame.sprite.Group()

clock = pygame.time.Clock()
pygame.init()
fon = pygame.image.load('fon.jpg')
screen.blit(fon, (0, 0))
pygame.display.set_caption('Реакция на события от мыши')
running = True
x_pos = 0
v = 20  # пикселей в секунду
fps = 60

player = Meshok()
start_screen()
level_1()
level_2()
level_3()
level_4()
level_5()
k = Gift.k
end_screen(k, Meshok.all_gifts, 3)
pygame.quit()
