import os
import pygame
import random
import sys
import sqlite3

# основные настройки игры
pygame.init()
font = pygame.font.Font(None, 32)
size = width, height = 824, 400
screen = pygame.display.set_mode(size)
screen_rect = (0, 0, 824, 340)

# фоновая музыка
fon_sound = pygame.mixer.Sound('data/sound/fon.mp3')
play_fon_sound = fon_sound.play(-1)
play_fon_sound.set_volume(0.1)


def terminate():
    pygame.quit()
    sys.exit()


# функция для загрузки картинки
def load_image(name, color_key=None):
    fullname = os.path.join('data/img/' + name)
    image = pygame.image.load(fullname).convert()

    if color_key is not None:
        if color_key == -1:
            color_key = image.get_at((0, 0))

        image.set_colorkey(color_key)

    else:
        image = image.convert_alpha()

    return image


# функция для заставки в начале игры
def start_screen():
    intro_text = ["Правила игры:",
                  "цель этой игры - это  собирать подарки.",
                  "Подарки будут падать сверху."
                  "Игрок должен собрать их,",
                  "управляя новогодним мешком,",
                  "При этом если вы потеряете 3 жизни - погибните, ",
                  "За каждый пропущенных подарок снимается 1 жизнь."
                  "",
                  "Для управления направлением движения",
                  "нужно нажимать на соответствующие кнопки-стрелки",
                  "",
                  "Для того чтобы начать игру, нажмите любую клавишу"]

    # трансформация и отрисовка фоновой картинки
    fon = pygame.transform.scale(load_image('start_image.png'), (width, height))
    screen.blit(fon, (0, 0))
    # тиль шрифта и размер текста
    font = pygame.font.Font(None, 30)
    # координата начала текста
    text_coord = 50
    fps = 60

    for line in intro_text:
        string_rendered = font.render(line, 1, pygame.Color('black'))
        intro_rect = string_rendered.get_rect()

        text_coord += 10
        intro_rect.top = text_coord
        intro_rect.x = 10
        text_coord += intro_rect.height

        screen.blit(string_rendered, intro_rect)

    while True:

        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                terminate()  # выход

            elif event.type == pygame.KEYDOWN:
                return  # начало игры

        pygame.display.flip()
        clock.tick(fps)


# функция для заставка в конце игры
def end_screen(k, all_gifts, lif):
    fps = 60
    intro_text = ["Спасибо за игру!",
                  "Что мы имеем в итоге:",
                  "Вы собрали аж " + str(k) + " подарков из " + str(all_gifts),
                  "Количество оставшихся жизней всего " + str(lif),
                  "На этом всё!",
                  "Далее необходимо закрыть окно,",
                  "нажав на крестик или пробел.",
                  "Или нажмите на пробел для того, чтобы посмотреть пожелание на Новый год."]

    if Meshok.lif < 0:
        intro_text[3] = "У вас не осталось жизней, к сожалению, вы проиграли. "
        intro_text[0] = "GAME OVER"

    if Gift.k == 0:
        intro_text[0] = "GAME OVER"

    if Meshok.lif == 3 and Gift.k >= Meshok.all_gifts:
        intro_text = ["YOU WIN!",
                      "Что мы имеем в итоге:",
                      "Вы собрали " + str(k) + " подарков" + ' из ' + str(Meshok.all_gifts),
                      "Количество оставшихся жизней всего " + str(Meshok.lif),
                      "На этом всё!",
                      "Далее необходимо закрыть окно,",
                      "нажав на крестик.",
                      "Или нажмите на пробел для того, чтобы посмотреть пожелание на Новой год."]

    fon = pygame.transform.scale(load_image('start_image.png'), (width, height))
    screen.blit(fon, (0, 0))

    font = pygame.font.Font(None, 30)
    text_coord = 50

    for line in intro_text:
        string_rendered = font.render(line, 1, pygame.Color('black'))
        intro_rect = string_rendered.get_rect()

        text_coord += 15
        intro_rect.top = text_coord
        intro_rect.x = 15
        text_coord += intro_rect.height

        screen.blit(string_rendered, intro_rect)

    while True:

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()

            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    pojelaniya()

        pygame.display.flip()
        clock.tick(fps)


# класс отвечающий за хранение информации о координатах подарков и попал ли подарок в мешок и счет полученных подарков
class Gift(pygame.sprite.Sprite):
    k = 0

    def __init__(self, lev, name):
        Gift.image = load_image(name, -1)

        if lev == 1:
            dlyn = 100
            raz = 20

        elif lev == 2:
            dlyn = 90
            raz = 10

        elif lev == 3:
            dlyn = 80
            raz = 10

        elif lev == 4:
            dlyn = 70
            raz = 10

        elif lev == 5:
            dlyn = 60
            raz = 10

        elif str(lev) == 'bonus_level':
            dlyn = 60
            raz = 10

        self.image = pygame.transform.scale(Gift.image, (dlyn + raz, dlyn + raz))

        # НЕОБХОДИМО вызвать конструктор родительского класса Sprite
        super().__init__(gift_group, all_sprites)
        self.rect = pygame.Rect((0, 0, dlyn, dlyn))
        self.rect.x = random.randint(40, 760 - dlyn)
        self.rect.y = 0

    # функция изменяющая координаты подарка
    def update(self):
        self.rect.y += 1

        # условие проверяющие дошёл ли подарок до границ rect экрана (если игрок пропустил подарок)
        if not self.rect.colliderect(screen_rect):
            self.kill()
            Meshok.ne_sobr += 1

            # добавляем звук
            error = pygame.mixer.Sound('data/sound/error.mp3')
            error_sound = error.play(0)
            error_sound.set_volume(150)

        # условие проверяющие находрится ли подарок внутри мешка (собрал ли игрок подарок)
        if Meshok.rect.contains(self.rect):
            self.kill()
            if not Meshok.bonus_flag:
                Gift.k += 1
            else:
                Meshok.bonus += 1
            ho_ho = pygame.mixer.Sound('data/sound/santa.mp3')
            gift_sound = ho_ho.play(0)
            gift_sound.set_volume(0.4)


# класс отвечающий за хранение информации о координатах мешка, оставшищся жизнях игрока, на каком уровне игрок
# находится и сколько подарков он не собрал
class Meshok(pygame.sprite.Sprite):
    image = load_image("mesh2.png", -1)
    level = 1
    all_gifts = 0
    do = True
    ne_sobr = 0
    lif = 3

    def __init__(self):
        # НЕОБХОДИМО вызвать конструктор родительского класса Sprite
        super().__init__(player_sprites, all_sprites)
        self.image = Meshok.image
        self.rect = pygame.Rect((270, 270, 340, 300))
        self.image = pygame.transform.scale(self.image, (250, 250))

        # прямоугольная область с которой будет проверка на попадание подарка в мешок
        Meshok.rect = pygame.Rect(300, 260, 200, 190)

    # функция изменяющая координаты мешка
    def update(self, x):
        self.rect.x += x
        Meshok.rect.x += x


# основная функция для создания уровней
def base_level(all_gifts, fps2, step2, lev, long=False):
    fps = 60
    intro_text = ["Пауза",
                  "Что мы имеем на данный момент:",
                  "Вы собрали " + str(Gift.k) + " подарков из " + str(Meshok.all_gifts),
                  "Количество оставшихся жизней всего " + str(Meshok.lif),
                  "",
                  "Для того чтобы продолжить игру, нажмите на пробел"]

    if long:
        intro_text = ["Пауза.",
                      "",
                      "В бонусном уровне вы собираете подарки",
                      "до тех пор пока не пропустите подарок.",
                      "После бонусного уровня вы сможите увидеть свой рейтинг",
                      "и рекорд бонусного уровня.",
                      "Для того чтобы запустить бонусный уровень, нажмите на пробел."]

    fon = pygame.transform.scale(load_image('start_image.png'), (width, height))
    screen.blit(fon, (0, 0))
    font = pygame.font.Font(None, 30)
    text_coord = 50

    for line in intro_text:
        string_rendered = font.render(line, 1, pygame.Color('black'))
        intro_rect = string_rendered.get_rect()
        text_coord += 15
        intro_rect.top = text_coord
        intro_rect.x = 15
        text_coord += intro_rect.height
        screen.blit(string_rendered, intro_rect)

    run = True
    while run and Meshok.do:

        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                terminate()

            elif event.type == pygame.KEYDOWN:

                if event.key == pygame.K_SPACE:
                    run = False  # начинаем игру

        pygame.display.flip()
        clock.tick(fps)

    Meshok.all_gifts += all_gifts

    gift_group = pygame.sprite.Group()
    upav_gifts = 0
    fps = fps2

    t = 110
    tip = 1

    fon = load_image('fon.jpg')
    running = True

    while running and Meshok.do:
        step = 0

        if (t % 110 == 0 and upav_gifts < all_gifts) or (long and t % 110 == 0):
            if tip % 6 == 1:
                name = "podar4.png"

            elif tip % 6 == 2:
                name = "podar.png"

            elif tip % 6 == 3:
                name = "podar2.png"

            elif tip % 6 == 4:
                name = "podar3.png"

            elif tip % 6 == 5:
                name = "podar5.png"

            elif tip % 6 == 0:
                name = "podar6.png"
                tip = 0

            gift_group.add(Gift(lev, name))
            upav_gifts += 1
            tip += 1

        font = pygame.font.Font(None, 32)

        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                running = False
                Meshok.do = False

            if event.type == pygame.KEYDOWN:

                if event.key == pygame.K_LEFT:

                    if Meshok.rect.x - step2 >= 5:
                        step = -1 * step2

                    else:
                        step = 20 - Meshok.rect.x

                if event.key == pygame.K_RIGHT:

                    if Meshok.rect.x + step2 <= 610:
                        step = step2

        t += 1

        # заливаем экран черным
        screen.fill('black')

        # отрисовываем фон
        screen.blit(fon, (0, 0))

        # прорисовываем по очереди все спрайты
        all_sprites.draw(screen)
        player_sprites.draw(screen)
        player_sprites.update(step)
        gift_group.update()

        if long:
            # задаём текст с уровнем, собранными подарками и оставшимися жизнями
            if Meshok.level == 6:
                Meshok.level = 'Бонусный уровень'

            text = font.render(
                str(Meshok.level) + " Подарков " + str(Meshok.bonus),
                None, (255, 255, 255))

        else:
            text = font.render(
                "Уровень " + str(Meshok.level) + " Подарков " + str(Gift.k) + " из " + str(Meshok.all_gifts) +
                " Осталось жизней " + str(Meshok.lif),
                None, (255, 255, 255))

        # размещаем текст на кране
        screen.blit(text, (10, 5))

        clock.tick(fps)
        pygame.display.flip()

        # условие перехода на новый уровень
        if len(gift_group) == 0 and upav_gifts > 0:
            running = False
            Meshok.level += 1

        # изменение количества жизней по пропущенным подаркам
        if Meshok.ne_sobr == 1:
            if long:
                Meshok.do = False
            else:
                Meshok.ne_sobr = 0
                Meshok.lif -= 1

        # выход из игры если не осталось жизней
        if Meshok.lif < 0:
            Meshok.do = False


# фукнция выводящая на экран фон с пожеланиями на Новый год.
def pojelaniya():
    running = True
    font = pygame.font.Font(None, 40)

    # список с пожеланиями
    text = ['Цель совсем рядом не сдавайтесь',
            'Действуйте! Всё получится.',
            'Если появится возможность - воспользуйтесь ею.',
            'Вы двигаетесь в правильном направлении.',
            'Вас ждёт предложение, о котором вы мечтали.',
            'Счастье в ваших руках.',
            'Обязательно пробуйте все новое и неизведанное.',
            'Судьбоносная встреча перевернет вашу жизнь.',
            'Скоро вы узнаете ответ на свой главный вопрос.',
            'Вы надеетесь не напрасно.',
            'Если закроется одна дверь, то откроется другая.',
            'Грядут перемены к лучшему.',
            'Новые страны ждут вас.',
            'В этом году вы увидите море.',
            'Друзья поддержат вас в любую минуту.']

    fps = 10
    key = 0
    last_text = ''

    while running:

        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                terminate()

            if event.type == pygame.KEYDOWN:

                if event.key == pygame.K_DOWN:
                    key = -1

                if event.key == pygame.K_UP:
                    bonus_level()

                if event.key == pygame.K_SPACE:
                    Meshok.lif = 3
                    return_game()

        fon = pygame.transform.scale(load_image('start_image.png', -1), (width, height))
        screen.blit(fon, (0, 0))

        if key != -1:
            output_text = random.choice(text)
            last_text = output_text

        else:
            output_text = last_text
            last_text = output_text

        all_text = [output_text, 'Чтобы выйти нажмите на крестик.', 'Чтобы начать игру заново нажмите пробел.',
                    'Чтобы увидеть пожелание нажмите стрелку вниз.',
                    'Чтобы запустить бонусный уровень', 'нажмите стрклку вверх']

        coord_y = 100

        p = 0

        for line in all_text:

            if p == 4 or p == 5:
                color = 'red'

            else:
                color = 'black'

            p += 1

            string_rendered = font.render(line, 1, pygame.Color(color))
            intro_rect = string_rendered.get_rect()

            intro_rect.top = coord_y
            coord_y += 15
            intro_rect.x = 20
            coord_y += intro_rect.height

            screen.blit(string_rendered, intro_rect)

        clock.tick(fps)
        pygame.display.flip()


def usl_lev(file_name):
    k = 1
    f = open(file_name)

    for line in f:
        if k == 1:
            all_gifts = line

        if k == 2:
            fps = line

        if k == 3:
            step = line

        if k == 4:
            lev = line.strip('\n')

        if k == 5:
            long = line

        k += 1

    return int(all_gifts), int(fps), int(step), lev, long


# создание первого уровня
def level_1():
    all_gifts, fps, step, lev, long = usl_lev('1.txt')

    base_level(all_gifts, fps, step, int(lev))


# сохдание второго уровня
def level_2():
    all_gifts, fps, step, lev, long = usl_lev('2.txt')

    base_level(all_gifts, fps, step, int(lev))


# создание третьего уровня
def level_3():
    Meshok.level = 3
    all_gifts, fps, step, lev, long = usl_lev('3.txt')

    base_level(all_gifts, fps, step, int(lev))


# создание четвёртого уровня
def level_4():
    all_gifts, fps, step, lev, long = usl_lev('4.txt')

    base_level(all_gifts, fps, step, int(lev))


# создание пятого уровня
def level_5():
    all_gifts, fps, step, lev, long = usl_lev('5.txt')

    base_level(all_gifts, fps, step, int(lev))


def bonus_level():
    all_gifts, fps, step, lev, long = usl_lev('6.txt')
    Meshok.do = True
    Meshok.bonus_flag = True
    Meshok.ne_sobr = 0
    Meshok.level = 6
    Meshok.bonus = 0

    for elem in gift_group:
        elem.kill()

    gift_group.empty()

    base_level(all_gifts, fps, step, lev, long)

    # Подключение к БД
    con = sqlite3.connect("reiting.sqlite")
    s = {}
    a = {}
    gifts = Meshok.bonus

    # Создание курсора
    cur = con.cursor()

    # Выполнение запроса и получение всех результатов
    result = cur.execute("""SELECT record FROM record""").fetchone()

    # Вывод результатов на экран
    for elem in result:
        if elem < gifts:
            cur.execute("UPDATE record SET record = ?", (gifts,))
            con.commit()
            record = gifts
        else:
            record = elem

    # Создание курсора
    cur = con.cursor()

    # Выполнение запроса и получение всех результатов
    result = cur.execute("""SELECT * FROM reit""").fetchall()

    for elem in result:
        s[elem[0]] = elem[1]
        cur.execute("DELETE FROM reit WHERE reiting = ?", (elem[0],))
        con.commit()

    if not result:
        s[1] = gifts

    if result:
        for elem in s:
            if elem + 1 not in s:
                x = elem + 1
    else:
        x = 1
    s[x] = gifts
    sorted_values = sorted(s.values(), reverse=True)
    w = 1
    for elem in sorted_values:
        a[w] = elem
        w += 1
    for elem in a:
        cur.execute('''INSERT INTO reit (reiting, gifts) VALUES (?, ?)''', (elem, a[elem]))
        con.commit()

    # Выполнение запроса и получение всех результатов
    result = cur.execute("""SELECT reiting FROM reit WHERE gifts = ?""", (gifts,)).fetchone()
    for elem in result:
        your_place = elem
    con.close()

    intro_text = ["Спасибо за игру!",
                  "Вы собрали аж " + str(Meshok.bonus) + " подарков.",
                  "И занимаете место в рейтинге:  " + str(your_place),
                  "Рекорд на бонусном уровне: " + str(record),
                  "На этом всё!",
                  "Далее необходимо закрыть окно, нажав на крестик.",
                  "Или нажмите на пробел чтрбы пройти игру заново.",
                  "Или нажмите на стрелочку вверх, чтобы перепройти бонусный уровень"]

    fon = pygame.transform.scale(load_image('start_image.png'), (width, height))
    screen.blit(fon, (0, 0))

    font = pygame.font.Font(None, 30)
    text_coord = 50

    for line in intro_text:
        string_rendered = font.render(line, 1, pygame.Color('black'))
        intro_rect = string_rendered.get_rect()

        text_coord += 15
        intro_rect.top = text_coord
        intro_rect.x = 15
        text_coord += intro_rect.height

        screen.blit(string_rendered, intro_rect)

    while True:

        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                terminate()

            if event.type == pygame.KEYDOWN:

                if event.key == pygame.K_UP:
                    bonus_level()

                if event.key == pygame.K_SPACE:
                    Meshok.l = 3
                    return_game()

        pygame.display.flip()


try:
    # группа, содержащая все спрайты
    all_sprites = pygame.sprite.Group()

    # группа содержащая спрайт мешка
    player_sprites = pygame.sprite.Group()

    # группа содержащая спрайты подарков
    gift_group = pygame.sprite.Group()

    clock = pygame.time.Clock()

    player = Meshok()


    def return_game():
        pygame.init()

        Meshok.do = True
        Meshok.ne_sobr = 0
        Meshok.all_gifts = 0
        Gift.k = 0
        Meshok.level = 1
        Meshok.lif = 3
        Meshok.bonus_flag = False

        gift_group.empty()
        all_sprites.empty()
        player_sprites.empty()

        player = Meshok()

        fon = pygame.image.load('data/img/fon.jpg')
        screen.blit(fon, (0, 0))

        pygame.display.set_caption('Ловец подарков')

        # запускаем начальный экран
        start_screen()

        # запускаем по очереди уровни
        level_1()
        level_2()
        level_3()
        level_4()
        level_5()

        # запускаем конечный экран
        end_screen(Gift.k, Meshok.all_gifts, Meshok.lif)
        # завершение работы:
        pygame.quit()

except Exception as e:
    print(type(e).__name__, e.args)
    exit()

if __name__ == '__main__':
    return_game()
